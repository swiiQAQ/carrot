---
title: 编译sass环境搭建
date: 2017-06-27 14:49:21
tags:
---
## 一、 通过koala编译sass
### 1、 下载安装ruby
进入该网站选择版本下载后安装[https://rubyinstaller.org/downloads/](https://rubyinstaller.org/downloads/)
***
**安装时，三个勾都打上**

![编译sass环境搭建](/img/编译sass环境搭建.png)

### 2、安装sass
> gem install sass

### 3、安装koala
进入下载即可[http://koala-app.com/](http://koala-app.com/)
***
进入设置选择sass后选择使用系统中的sass编译器

![编译sass环境搭建1](/img/编译sass环境搭建1.png)
***
设置输出目录

右键编译的sass文件，设置输出目录

## 二、通过webstom编译sass
### 1、 前两步同上
### 2、 进入下载即可[http://www.jetbrains.com/webstorm/](http://www.jetbrains.com/webstorm/)
***
![编译sass环境搭建4](/img/编译sass环境搭建4.png)