---
title: css一些我总是记不住又神奇的东西
date: 2017-09-29 15:00:31
tags:
---
### text-shadow
>text-shadow: x-shadow y-shadow blur color;

```HTML
    <h1 style="color:white;text-shadow:2px 2px 4px #000000;">白色文本的阴影效果！</h1>
```
<h1 style="color:white;text-shadow:2px 2px 4px #000000;">白色文本的阴影效果！</h1>
```HTML
<div style="background:#666;width:200px">
    <h1 style="color: #eee;text-shadow: 6px 6px 0 #666, 7px 7px 0 #eee;">VINTAGE RETRO</h1>
</div>
```
<div style="background:#666;width:200px">
    <h1 style="color: #eee;text-shadow: 6px 6px 0 #666, 7px 7px 0 #eee;">VINTAGE RETRO</h1>
</div>

```HTML
<div style="background:#666">
    <h1 style="color: transparent;text-shadow:0 0 6px #F96, -1px -1px  #FFF, 1px -1px  #444">World</h1>
</div>
```
<div style="background:#666">
    <h1 style="color: transparent;text-shadow:0 0 6px #F96, -1px -1px  #FFF, 1px -1px  #444">World</h1>
</div>

### box-shadow
>box-shadow:inset x-shadow y-shadow blur spread color ;
x-shadow: 水平阴影的位置(required)；
y-shadow: 垂直阴影的位置(required)；
blur: 模糊距离；
spread: 阴影的尺寸；
color： 阴影的颜色(mz和opera缺省下为黑色，webkit为透明)；
inset/outset：内部阴影/外部阴影(缺省默认)；

